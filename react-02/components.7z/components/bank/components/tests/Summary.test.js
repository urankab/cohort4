import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import AccountsApp from '../AccountsApp'
import Summary from '../Summary'
import funcs from '../../business/functions'

// test('Test summary', () => {
//    // const mockTotal = jest.fn()
//    // const mockHighest = jest.fn()
//    // const mockLowest = jest.fn()
//    // const mockAll = jest.fn()

//    // render(<Summary
//    //    totalStuff={mockTotal}
//    //    highestStuff={mockHighest}
//    //    lowestStuff={mockLowest}
//    //    showStuff={mockAll}
//    // />)
// })

